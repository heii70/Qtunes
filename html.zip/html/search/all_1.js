var searchData=
[
  ['defaultimage',['defaultImage',['../class_squares_widget.html#abed735442728e615d29a6226915c6a0e',1,'SquaresWidget']]]
];
