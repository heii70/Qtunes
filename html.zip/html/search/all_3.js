var searchData=
[
  ['imagefortag',['imageForTag',['../class_main_window.html#a389e131ef810f20b782727ff975f89d7',1,'MainWindow::imageForTag()'],['../class_squares_widget.html#a8bd6af60000faa0833c646d54d33b8ce',1,'SquaresWidget::imageForTag()']]],
  ['initializegl',['initializeGL',['../class_squares_widget.html#acb23365c9e3fe736d7e6d1684ef52f78',1,'SquaresWidget::initializeGL()'],['../class_visualizer_widget.html#a552249fa383f2b2b176a2c2515118ad5',1,'VisualizerWidget::initializeGL()']]],
  ['initlists',['initLists',['../class_main_window.html#a068ee0dd2a70802ed972168ed1a1dcf6',1,'MainWindow']]]
];
