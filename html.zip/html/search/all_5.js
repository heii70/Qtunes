var searchData=
[
  ['mainwindow',['MainWindow',['../class_main_window.html',1,'MainWindow'],['../class_main_window.html#a6ddfd0e7db77410eb79c550f5404b772',1,'MainWindow::MainWindow()']]],
  ['mousedoubleclickevent',['mouseDoubleClickEvent',['../class_squares_widget.html#a8717803228084f7353ddec567e09d6a1',1,'SquaresWidget']]],
  ['mousepressevent',['mousePressEvent',['../class_squares_widget.html#ae4bc4bd6c721bc4392956e34c8ccda40',1,'SquaresWidget']]]
];
