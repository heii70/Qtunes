var searchData=
[
  ['paintgl',['paintGL',['../class_squares_widget.html#a05c6c230caedfc57fbe003783d88629e',1,'SquaresWidget::paintGL()'],['../class_visualizer_widget.html#a6be9ffb9f7ec557d2ffbd5f04a62ea79',1,'VisualizerWidget::paintGL()']]]
];
