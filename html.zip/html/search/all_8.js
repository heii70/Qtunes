var searchData=
[
  ['redrawlists',['redrawLists',['../class_main_window.html#a03487ecf2fa3fecbb88ec4bc28daff1e',1,'MainWindow']]],
  ['resizegl',['resizeGL',['../class_squares_widget.html#ac7fadb41dabd204f24f423004a06fb63',1,'SquaresWidget::resizeGL()'],['../class_visualizer_widget.html#ad8177d473032aaf76443c1d0cdaba121',1,'VisualizerWidget::resizeGL()']]]
];
