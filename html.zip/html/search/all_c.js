var searchData=
[
  ['_7emainwindow',['~MainWindow',['../class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]],
  ['_7esquareswidget',['~SquaresWidget',['../class_squares_widget.html#a1da6c6f83b4d81635c8c7f5b3f5555d2',1,'SquaresWidget']]],
  ['_7evisualizerwidget',['~VisualizerWidget',['../class_visualizer_widget.html#a202051cbd73be7bb0563aee58569d824',1,'VisualizerWidget']]]
];
