var searchData=
[
  ['squareswidget',['SquaresWidget',['../class_squares_widget.html',1,'']]]
];
