var searchData=
[
  ['visualizerwidget',['VisualizerWidget',['../class_visualizer_widget.html#a8a6b2e48cd99c910dfc97923be4cec1a',1,'VisualizerWidget']]]
];
